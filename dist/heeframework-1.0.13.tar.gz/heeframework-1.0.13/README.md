**【HeeFramework】**  
***
A module-oriented comprehensive IOC container framework, which realizes the automatic management of dependent components and component dependencies, and defines a new python module organization.


